<?php

namespace Iyzipay\Model;

class PaymentGroup
{
    const PRODUCT = "PRODUCT";
    const LISTING = "LISTING";
    const SUBSCRIPTION = "SUBSCRIPTION";
}